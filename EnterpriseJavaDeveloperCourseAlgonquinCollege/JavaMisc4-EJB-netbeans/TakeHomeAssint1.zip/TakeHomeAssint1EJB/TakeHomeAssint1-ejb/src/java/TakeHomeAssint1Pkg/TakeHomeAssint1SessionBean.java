/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TakeHomeAssint1Pkg;

import java.math.BigDecimal;
//import java.math.MathContext;
import javax.ejb.Stateless;

/**
 *
 * @author rmorton
 */
@Stateless
public class TakeHomeAssint1SessionBean implements TakeHomeAssint1SessionBeanRemote {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
    private BigDecimal dollarToYenRate = new BigDecimal("85.7510138");
    private BigDecimal euroToYenRate = new BigDecimal("120.340633");

    @Override
    public BigDecimal dollarToYen(BigDecimal dollars) {
         BigDecimal result = dollars.multiply(dollarToYenRate);
         return result.setScale(2, BigDecimal.ROUND_UP);
    }

    @Override
    public BigDecimal yenToDollar(BigDecimal yen) {
         BigDecimal result = yen.divideToIntegralValue(dollarToYenRate);
         return result.setScale(2, BigDecimal.ROUND_UP);
    }

    @Override
    public BigDecimal yenToEuro(BigDecimal yen) {
         BigDecimal result = yen.divideToIntegralValue(euroToYenRate);
         return result.setScale(2, BigDecimal.ROUND_UP);
    }

    @Override
    public BigDecimal euroToYen(BigDecimal euro) {
         BigDecimal result = euro.multiply(euroToYenRate);
         return result.setScale(2, BigDecimal.ROUND_UP);
    }


}
