/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TakeHomeAssint2EJBPackage;

import java.math.BigDecimal;
import javax.ejb.Remote;
import javax.ejb.Stateful;
import javax.interceptor.Interceptors;

/**
 *
 * @author rmorton
 */
@Stateful
@Remote(TakeHomeAssint2EJBPackage.TakeHomeAssint2EJBRemote.class)
@Interceptors(TakeHomeAssint2EJBPackage.TakeHomeAssint2EJBCallBacks.class)
public class TakeHomeAssint2EJB implements TakeHomeAssint2EJBRemote {

    private BigDecimal balance;
    private int transactionID=0;

    @Override
    public void initBalance(BigDecimal initBalance) {
        balance=initBalance;
        balance = balance.setScale(2, BigDecimal.ROUND_UP);
        System.out.println("EJB: business method: initBalance: balance: $" + balance);
    }


    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public BigDecimal getBalance() {
        System.out.println("EJB: business method: getBalance: balance: $" + balance);
        return balance;
    }

    @Override
    public int deposit(BigDecimal deposit) {
        balance=balance.add(deposit);
        balance = balance.setScale(2, BigDecimal.ROUND_UP);        
        transactionID++;
        System.out.println("EJB: transaction: deposit: $" + deposit + 
            " transaction ID: " + 
            transactionID + " balance: $" + balance);
        return transactionID;
    }

    @Override
    public int withdraw(BigDecimal withdrawal) {
        balance=balance.subtract(withdrawal);
        balance = balance.setScale(2, BigDecimal.ROUND_UP);
        transactionID++;
        System.out.println("EJB: transaction: withdrawal: $" + withdrawal + 
            " transaction ID: " + 
            transactionID + " balance: $" + balance);
        return transactionID;
    }
    
}
