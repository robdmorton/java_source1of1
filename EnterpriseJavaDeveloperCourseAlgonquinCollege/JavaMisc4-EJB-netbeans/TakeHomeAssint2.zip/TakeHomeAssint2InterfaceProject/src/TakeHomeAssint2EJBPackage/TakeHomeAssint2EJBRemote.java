/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TakeHomeAssint2EJBPackage;

import java.math.BigDecimal;
import javax.ejb.Remote;

/**
 *
 * @author rmorton
 */
@Remote
public interface TakeHomeAssint2EJBRemote {

    void initBalance(BigDecimal initBalance);

    BigDecimal getBalance();

    int deposit(BigDecimal deposit);

    int withdraw(BigDecimal withdrawal);

    
}
