/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeassint2clientproject;

import TakeHomeAssint2EJBPackage.TakeHomeAssint2EJBRemote;
import java.math.BigDecimal;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
        
/**
 *
 * @author rmorton
 */
public class TakeHomeAssint2Client {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("CallToThreadDumpStack")
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            /* Get a reference to the bean */
            Context ctx = new InitialContext(System.getProperties());
            TakeHomeAssint2EJBRemote bank = (TakeHomeAssint2EJBRemote) 
                    ctx.lookup(TakeHomeAssint2EJBRemote.class.getName());
            
            int transactionID;
            bank.initBalance(BigDecimal.ZERO);
            System.out.println("balance: " + bank.getBalance());
            transactionID = bank.deposit(new BigDecimal(500000.99));
            System.out.println("balance: " + bank.getBalance() + 
                    " transactionID: " + transactionID);
            transactionID = bank.withdraw(new BigDecimal(600000.66));
            System.out.println("balance: " + bank.getBalance() + 
                    " transactionID: " + transactionID);
        } catch (NamingException ex) {
            ex.printStackTrace();
        }
    }
}
