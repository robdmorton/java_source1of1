/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CallByRefOrByValue;

import javax.ejb.Stateless;

/**
 *
 * @author rmorton
 */
@Stateless
public class CallByRefOrByValue implements CallByRefOrByValueRemote {

    @Override
    public void change(int myarray[]) {
        int temp;
        System.out.println("Within(before): " + myarray[0] + " " + myarray[1]);
        temp = myarray[0];
        myarray[0]=myarray[1];
        myarray[1]=temp;
        //follwing split into multiple line in GlassFish server log
        //see: http://www.google.ca/search?sourceid=chrome&ie=UTF-8&q=glassfish+and+printf
        //see: http://markmail.org/message/gx36rkq7j5hqvmd3
//        System.out.printf("Within: %d %d\n",myarray[0],myarray[1]);
        System.out.println("Within(after): " + myarray[0] + " " + myarray[1]);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
}
