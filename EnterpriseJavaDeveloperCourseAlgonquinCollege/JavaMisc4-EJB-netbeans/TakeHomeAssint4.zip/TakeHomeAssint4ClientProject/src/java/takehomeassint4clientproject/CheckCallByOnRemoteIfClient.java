/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package takehomeassint4clientproject;

import CallByRefOrByValue.CallByRefOrByValueRemote;
import javax.ejb.EJB;


/**
 *
 * @author rmorton
 */
public class CheckCallByOnRemoteIfClient {
    
    private class Dog
    {
        String name;
        
        Dog(String inName)
        {
            name = inName;
        }
        
        void setName(String inName)
        {
            name = inName;
        }
        
        String getName()
        {
            return name;
        }
    
    }
    
    private void fooCheckCallBy()
    {
        Dog myDog = new Dog("Rover");
        System.out.println("outside foo method(before):" + myDog.getName());
        foo(myDog);
        System.out.println("outside foo method(after):" + myDog.getName());
        System.out.println("proof that Java is pass-by-value...or..."
                + "more explicitly..." + "\"object references "
                + "are passed by value\"");
    }
    
    private void foo(Dog inDog)
    {
        inDog.setName("Max");
        System.out.println("in foo method(before):" + inDog.getName());
        inDog = new Dog("Fifi");
        inDog.setName("Rowlf");
        System.out.println("in foo method(after):" + inDog.getName());
    }
    
    @EJB
    private static CallByRefOrByValueRemote callByRefOrByValue;

   /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int intArray[]={1,2};
        
        System.out.printf("Before %d %d\n",intArray[0],intArray[1]);
        callByRefOrByValue.change(intArray);
        System.out.printf("After %d %d\n",intArray[0],intArray[1]);
        System.out.printf("Remote invocations are pass-by-value\n"); 
        System.out.printf("...let's see an example of how JSE Java is pass-by-value and NOT pass-by-reference:\n"); 
        CheckCallByOnRemoteIfClient myObject=new CheckCallByOnRemoteIfClient();
        myObject.fooCheckCallBy();
    }
}
