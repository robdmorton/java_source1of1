package intermediateJavaProgramming.lab1;

@SuppressWarnings("serial")
public class MyException extends Exception 
{
//  MyException() { super(); }
//  MyException(String s) { super(s); }
//  MyException(Throwable cause) { super(cause); }
}
