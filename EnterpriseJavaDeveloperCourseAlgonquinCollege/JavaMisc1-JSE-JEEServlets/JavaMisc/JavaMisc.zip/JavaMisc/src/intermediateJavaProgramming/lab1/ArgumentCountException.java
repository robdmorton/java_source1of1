package intermediateJavaProgramming.lab1;

@SuppressWarnings("serial")
public class ArgumentCountException extends Exception
{
	ArgumentCountException() { super(); }
	ArgumentCountException(String s) { super(s); }
}
