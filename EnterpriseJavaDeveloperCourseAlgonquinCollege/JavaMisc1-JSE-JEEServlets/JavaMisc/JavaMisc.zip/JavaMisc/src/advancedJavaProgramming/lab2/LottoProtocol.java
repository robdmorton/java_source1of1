package advancedJavaProgramming.lab2;



public class LottoProtocol {

    public static final int MAX_VALUE = 49;

    public static final int NUM_OF_NUMBERS = 6;

    public static final String SERVER_HOST = "localhost";

    public static final int SERVER_PORT = 5123;

    public static final String TICKET_REQUEST_COMMAND = "GetTicket";
}
