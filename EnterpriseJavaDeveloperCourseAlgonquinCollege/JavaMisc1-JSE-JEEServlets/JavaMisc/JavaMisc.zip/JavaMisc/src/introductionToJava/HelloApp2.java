package introductionToJava;

//Ch01-Version 2

// This application displays a hello message on
// the console by creating an instance of the
// Greeter class, then calling the Greeter
// object's sayHello method.

public class HelloApp2
{
	public static void main(String[] args)
	{
		Greeter g = new Greeter();
		g.sayHello();
	}
}


