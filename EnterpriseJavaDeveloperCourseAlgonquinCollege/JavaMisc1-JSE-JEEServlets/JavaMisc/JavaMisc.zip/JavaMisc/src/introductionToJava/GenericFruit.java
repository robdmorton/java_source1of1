package introductionToJava;

public class GenericFruit 
{

  int sweetness;
  
  GenericFruit()
  {
    
  }
  
  GenericFruit(int i)
  {
    sweetness = i;
  }
  
  int getSweetness()
  {
    return sweetness;
  }
}
