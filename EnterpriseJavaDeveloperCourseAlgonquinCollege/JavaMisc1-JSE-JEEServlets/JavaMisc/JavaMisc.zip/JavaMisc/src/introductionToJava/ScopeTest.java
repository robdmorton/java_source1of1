package introductionToJava;

public class ScopeTest {

  boolean testScope(){
    return true;
  }

}
