package introductionToJava;

public class Worker extends Person
{

  Worker()
  {
  }
  
}
