package introductionToJava.lab4;

public class Player {
	private String name;
	private int strength, speed, weapons;
	
	public Player(String name, int speed, int strength, int weapons) {
		
		this.name = name;
		this.speed = speed;
		this.strength = strength;
		this.weapons = weapons;
	}
	
	
	
	}
	
