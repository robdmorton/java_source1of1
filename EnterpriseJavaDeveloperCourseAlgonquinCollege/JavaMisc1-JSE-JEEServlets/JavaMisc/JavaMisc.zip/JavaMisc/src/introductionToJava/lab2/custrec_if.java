package introductionToJava.lab2;

public interface custrec_if {
	
	public String getname();
	public String getaddr();
	public void setname( String s );
	public void setaddr( String s );

}// end if
