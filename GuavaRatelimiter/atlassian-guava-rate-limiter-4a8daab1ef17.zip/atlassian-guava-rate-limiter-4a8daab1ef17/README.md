Single class - `RateLimiter` fork of Guava 15 to provide compatibility for JIRA renaissance.
